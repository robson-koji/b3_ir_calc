


""" CEI """
# CEI input file
CEI_INPUT_PATH = ''

# CEI output file
CEI_OUTPUT_PATH = ''


""" Local configuration """
try:
    from local_conf import *
except ImportError:
    pass
