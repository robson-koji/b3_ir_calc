

STOCK_INPUT_DATA'/home/robson/invest/mirae.csv'


CEI_INPUT_PATH = '/home/robson/invest/cei.txt'
CEI_OUTPUT_PATH = '/home/robson/invest/cei.csv'
