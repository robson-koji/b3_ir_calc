Calculte income tax for B3(BM&FBOVESPA) stock operations. 


Clone and run pytest. There is a sample CSV file included. 
